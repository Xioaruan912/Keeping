import sqlite3
import numpy as np

def calculate_average_score_by_team(db_path):
    # 连接到 SQLite 数据库
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # 查询所有评分数据，按区队分组
    cursor.execute('''
        SELECT 区队, 总分 FROM score
    ''')
    scores = cursor.fetchall()

    # 使用字典按区队分组分数
    team_scores = {}
    for team, score in scores:
        if team not in team_scores:
            team_scores[team] = []
        if score is not None:
            team_scores[team].append(score)

    # 输出每个区队的原始分数
    print("各区队的原始分数:")
    for team, scores in team_scores.items():
        print(f"{team}: {scores}")

    # 计算每个区队的平均分
    average_scores = {}
    for team, scores in team_scores.items():
        print(f"\n计算区队 {team} 的平均分:")
        if len(scores) < 10:
            average_scores[team] = np.mean(scores) if scores else 0
            print(f"  成员不足10人，直接计算平均分: {average_scores[team]:.2f}")
            continue

        # 将分数排序
        scores.sort()
        print(f"  排序后的分数: {scores}")

        # 计算去掉前10%和后10%后的平均值
        n = len(scores)
        lower_bound = int(n * 0.1)  # 前10%的索引
        upper_bound = int(n * 0.9)  # 后10%的索引

        # 取出中间的分数
        trimmed_scores = scores[lower_bound:upper_bound]
        print(f"  去掉前10%和后10%后的分数: {trimmed_scores}")

        # 计算平均值
        average_scores[team] = np.mean(trimmed_scores) if trimmed_scores else 0
        print(f"  去掉极端分数后的平均分: {average_scores[team]:.2f}")

    # 关闭数据库连接
    conn.close()

    return average_scores

# 使用示例
db_path = '信息网络安全大队_数据库文件.db'  # 请替换为你的数据库路径
average_scores_by_team = calculate_average_score_by_team(db_path)

# 输出结果
print("\n最终各区队的平均分:")
for team, avg_score in average_scores_by_team.items():
    print(f"区队: {team}, 全区队评价成绩的平均值为: {avg_score:.2f}")