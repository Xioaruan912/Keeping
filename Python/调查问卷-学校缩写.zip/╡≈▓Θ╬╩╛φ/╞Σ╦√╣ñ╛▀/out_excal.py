import sqlite3
import numpy as np
import pandas as pd
import os

def calculate_average_score_by_team(db_path):
    # 连接到 SQLite 数据库
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # 查询所有评分数据，按区队分组
    cursor.execute('''
        SELECT 区队, 总分 FROM score
    ''')
    scores = cursor.fetchall()

    # 使用字典按区队分组分数
    team_scores = {}
    for team, score in scores:
        if team not in team_scores:
            team_scores[team] = []
        if score is not None:
            team_scores[team].append(score)

    # 输出每个区队的原始分数
    print("各区队的原始分数:")
    for team, scores in team_scores.items():
        print(f"{team}: {scores}")

    # 计算每个区队的平均分
    average_scores = {}
    for team, scores in team_scores.items():
        print(f"\n计算区队 {team} 的平均分:")
        if len(scores) < 10:
            average_scores[team] = np.mean(scores) if scores else 0
            print(f"  成员不足10人，直接计算平均分: {average_scores[team]:.2f}")
            continue

        # 将分数排序
        scores.sort()
        print(f"  排序后的分数: {scores}")

        # 计算去掉前10%和后10%后的平均值
        n = len(scores)
        lower_bound = int(n * 0.1)  # 前10%的索引
        upper_bound = int(n * 0.9)  # 后10%的索引

        # 取出中间的分数
        trimmed_scores = scores[lower_bound:upper_bound]
        print(f"  去掉前10%和后10%后的分数: {trimmed_scores}")

        # 计算平均值
        average_scores[team] = np.mean(trimmed_scores) if trimmed_scores else 0
        print(f"  去掉极端分数后的平均分: {average_scores[team]:.2f}")

    # 关闭数据库连接
    conn.close()

    return team_scores, average_scores

# 数据导出到 Excel 文件
def export_data_to_excel(db_path, output_folder, team_scores, average_scores):
    # 连接到 SQLite 数据库
    conn = sqlite3.connect(db_path)

    # 查询 user 表
    user_query = "SELECT * FROM users"
    user_df = pd.read_sql_query(user_query, conn)

    # 查询 score 表
    score_query = "SELECT * FROM score"
    score_df = pd.read_sql_query(score_query, conn)

    # 将学号字段转换为文本格式
    user_df['学号'] = user_df['学号'].astype(str)
    score_df['评分人学号'] = score_df['评分人学号'].astype(str)
    score_df['被评分学号'] = score_df['被评分学号'].astype(str)

    # 创建输出文件夹（如果不存在）
    os.makedirs(output_folder, exist_ok=True)

    # 将数据导出到 Excel 文件
    output_file_path = os.path.join(output_folder, 'output.xlsx')
    with pd.ExcelWriter(output_file_path) as writer:
        user_df.to_excel(writer, sheet_name='user', index=False)
        score_df.to_excel(writer, sheet_name='score', index=False)

        # 创建一个 DataFrame 存储区队的成绩和平均分
        team_scores_df = pd.DataFrame({
            '区队': list(team_scores.keys()),
            '平均分': [average_scores.get(team, 0) for team in team_scores.keys()]
        })

        # 将区队成绩和平均分导出到 Excel
        team_scores_df.to_excel(writer, sheet_name='区队成绩', index=False)

    # 关闭数据库连接
    conn.close()

    print(f"数据已成功导出到 {output_file_path}")

# 使用示例
db_path = '信息网络安全大队_数据库文件.db'  # 请替换为你的数据库路径
output_folder = 'output_folder'  # 请替换为你希望输出的文件夹路径

# 计算平均分
team_scores, average_scores_by_team = calculate_average_score_by_team(db_path)

# 输出结果
print("\n最终各区队的平均分:")
for team, avg_score in average_scores_by_team.items():
    print(f"区队: {team}, 全区队评价成绩的平均值为: {avg_score:.2f}")

# 导出数据到 Excel
export_data_to_excel(db_path, output_folder, team_scores, average_scores_by_team)